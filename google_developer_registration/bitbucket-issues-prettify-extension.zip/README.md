bitbucket-issues-prettify-extension
===================================

This chrome extension change Bitbucket issues view more prettify.


Getting Started
---------------

clone this repository

```
$ git clone git@github.com:ae06710/bitbucket-issues-prettify-extension.git
```

Add Extension

1. open chrome://extensions
2. check Developer mode
3. Load unpacked extension…

You can get prettify bitbucket issues view.

Enjoy!!

